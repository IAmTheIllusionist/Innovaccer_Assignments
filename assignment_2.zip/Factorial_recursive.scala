object Factorial{
def main(args:Array[String])
{


if (args.length <1 )
System.exit(1)
val x = args(0).toInt
if (x<1 ||  x>100){
println("Invalid Input")
}
val f = factorial(x)
println(s"$f") 
}

def factorial(x:Int):BigInt={
if(x<=1) return 1
else return x*factorial(x-1)
}
}
