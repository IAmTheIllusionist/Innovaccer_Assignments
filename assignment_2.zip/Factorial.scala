import scala.io.StdIn
object Factorial{
def main(args:Array[String])
{


if (args.length <1 )
System.exit(1)
val x = args(0).toInt
if (x<1 ||  x>100){
println("Invalid Input")
}
val f = factorial(x)
println(s"$f") 
}
def factorial(x:Int):BigInt={

var fact: BigInt = 1
for(i <- 2 to x){
fact *= i
}
return fact
}
}

