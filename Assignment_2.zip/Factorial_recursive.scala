import scala.io.StdIn
object Factorial_recursive{
def main(args:Array[String])
{
val x = StdIn.readInt()
println(factorial(x)) 
}
def factorial(x:Int):Double={
if(x<=1) return 1
else return x*factorial(x-1)
}
}
