import scala.io.StdIn
object Factorial{
def main(args:Array[String])
{
val x = StdIn.readInt()
println(factorial(x)) 
}
def factorial(x:Int):Double={

var fact = 1.0
for(i <- 2 to x){
fact *= i
}
return fact
}
}

