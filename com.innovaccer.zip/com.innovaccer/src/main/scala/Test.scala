import com.innovaccer._
import scala.io.StdIn
object Test
{
  def main(args:Array[String]): Unit =
  {
    val x = new Abc.InnoString(StdIn.readLine())
    val y = new Abc.InnoString(StdIn.readLine())
    println(x+y)
    println(x==y)
    println(x.isPalindrome())
  }
}