import com.innovaccer._
import scala.io.StdIn
object Hello
{
def main(args:Array[String])
{
println("Enter the requisite strings")
val x = StdIn.readLine()
val a = new Abc.InnoString(x)
val b = new Abc.InnoString(StdIn.readLine())
println(a+b)
println(a.isPalindrome())
}
}
